# Ledger — Task Manager (PWA)

A complete, installable to-do list Progressive Web App. Plain HTML/CSS/JS —
no build step, no frameworks, no dependencies. Works fully offline and
stores tasks in the browser's `localStorage`.

## Files

```
index.html          – app markup
style.css            – all styling (light + dark theme, responsive)
app.js                – all app logic (CRUD, filters, search, stats, storage)
manifest.json        – PWA manifest (name, icons, colors)
service-worker.js    – offline caching
icons/icon-192.png   – app icon
icons/icon-512.png   – app icon
icons/icon-512-maskable.png – adaptive icon for Android
```

## 1. Run it locally (to test on your laptop first)

You need a local web server — opening `index.html` directly with
`file://` will NOT work for the service worker / PWA install.

```bash
cd todoapp
python3 -m http.server 8080
```

Then open `http://localhost:8080` in Chrome. You should see the app,
be able to add/edit/delete tasks, and see an "Install" icon in the
address bar.

## 2. Put it on the internet (needed to install on your phone)

PWA install and service workers require **HTTPS** (localhost is the only
exception). Pick whichever is easiest:

**Option A — Netlify Drop (fastest, no account needed for testing)**
1. Go to https://app.netlify.com/drop
2. Drag the whole `todoapp` folder onto the page.
3. You'll get a live `https://xxxx.netlify.app` URL instantly.

**Option B — GitHub Pages (free, permanent, good if you'll keep iterating)**
1. Create a new GitHub repo and push the contents of `todoapp/` to it.
2. Repo → Settings → Pages → Deploy from branch → `main` → `/ (root)`.
3. Your app will be live at `https://<username>.github.io/<repo>/`.

**Option C — Vercel**
1. `npm i -g vercel` then run `vercel` inside the `todoapp` folder and follow the prompts.

## 3. Install it on your Android phone

1. Open the live HTTPS URL (from step 2) in **Chrome on Android**.
2. Tap the **⋮** menu → **Install app** (or you'll see a banner
   "Add Ledger to Home screen" — tap it).
3. Confirm. The app icon now appears on your home screen and opens
   full-screen, like a native app — no browser bar, with the splash
   screen and icon you saw in this build.
4. Turn on airplane mode and open it again — your tasks are still
   there and you can keep adding/editing/completing tasks offline.

(On iPhone: open the URL in Safari → Share → "Add to Home Screen".)

## 4. Turning this into a Play Store APK/AAB later

Because this is a standards-compliant PWA (manifest + service worker +
HTTPS), you can wrap it for the Play Store without rewriting anything:

1. Deploy it to a permanent HTTPS URL (GitHub Pages/Vercel/your own domain).
2. Go to **https://www.pwabuilder.com**, paste your URL.
3. It will score your manifest/service worker (this one is already
   built to pass) and let you download an **Android package** — choose
   the "Google Play (AAB)" option, generated via Google's own **Bubblewrap**
   / Trusted Web Activity tooling under the hood.
4. Open the generated Android Studio project (or use the signing tool
   PWABuilder provides) to sign the AAB with your own keystore, then
   upload it to the Play Console.

No code changes are needed for this step — the same `index.html`,
`app.js`, etc. keep running inside the wrapped app via a Trusted Web
Activity, so anything you fix here you can just redeploy.

## Notes on data storage

Tasks are stored locally on-device via `localStorage`, scoped to the
domain you deploy to. That means:
- Data persists across app restarts and offline use.
- Data is per-browser/per-device — it will not sync between your phone
  and laptop unless you add a backend later.
- Clearing site data/cache in the browser will erase tasks, same as
  any offline-first app.
