(() => {
  'use strict';

  const STORAGE_KEY = 'ledger_tasks_v1';
  const THEME_KEY = 'ledger_theme_v1';

  /* ---------- State ---------- */
  let tasks = [];
  let filter = 'all';          // all | active | completed
  let categoryFilter = 'all';
  let priorityFilter = 'all';
  let searchTerm = '';
  let pendingDeleteId = null;   // id awaiting confirmation, or 'COMPLETED' for bulk
  let editingId = null;         // id being edited, or null when adding

  /* ---------- Persistence ---------- */
  function loadTasks() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      tasks = raw ? JSON.parse(raw) : seedTasks();
    } catch (e) {
      console.error('Failed to load tasks', e);
      tasks = [];
    }
  }

  function saveTasks() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (e) {
      console.error('Failed to save tasks', e);
      showToast('Could not save — storage may be full.', 'error');
    }
  }

  function seedTasks() {
    const today = new Date();
    const inDays = (n) => {
      const d = new Date(today);
      d.setDate(d.getDate() + n);
      return d.toISOString().slice(0, 10);
    };
    const seeded = [
      {
        title: 'Welcome to Ledger 👋',
        notes: 'Tap the circle to complete a task, or tap a task to edit it.',
        priority: 'medium',
        category: 'Getting Started',
        dueDate: inDays(0),
        completed: false,
      },
      {
        title: 'Swipe through Active / Completed tabs',
        notes: 'Use the tabs to filter your list.',
        priority: 'low',
        category: 'Getting Started',
        dueDate: '',
        completed: false,
      },
      {
        title: 'This app works offline',
        notes: 'Your tasks are saved right on this device.',
        priority: 'high',
        category: 'Getting Started',
        dueDate: inDays(-1),
        completed: true,
      },
    ];
    return seeded.map((t) => ({ id: genId(), createdAt: Date.now(), ...t }));
  }

  function genId() {
    return 't_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  /* ---------- DOM refs ---------- */
  const $ = (sel) => document.querySelector(sel);
  const el = {
    app: $('#app'),
    boot: $('#boot-screen'),
    taskList: $('#task-list'),
    emptyState: $('#empty-state'),
    emptyTitle: $('#empty-title'),
    emptySub: $('#empty-sub'),
    deleteCompletedBtn: $('#delete-completed-btn'),
    statTotal: $('#stat-total'),
    statActive: $('#stat-active'),
    statDone: $('#stat-done'),
    statPercent: $('#stat-percent'),
    progressFill: $('#progress-fill'),
    searchInput: $('#search-input'),
    searchClear: $('#search-clear'),
    filterTabs: document.querySelectorAll('.filter-tab'),
    categoryFilter: $('#category-filter'),
    priorityFilter: $('#priority-filter'),
    fabAdd: $('#fab-add'),
    taskModal: $('#task-modal'),
    modalTitle: $('#modal-title'),
    modalClose: $('#modal-close'),
    modalCancel: $('#modal-cancel'),
    taskForm: $('#task-form'),
    taskTitleInput: $('#task-title'),
    taskNotesInput: $('#task-notes'),
    taskPriorityInput: $('#task-priority'),
    taskDueInput: $('#task-due'),
    taskCategoryInput: $('#task-category'),
    categorySuggestions: $('#category-suggestions'),
    confirmModal: $('#confirm-modal'),
    confirmTitle: $('#confirm-title'),
    confirmMessage: $('#confirm-message'),
    confirmCancel: $('#confirm-cancel'),
    confirmOk: $('#confirm-ok'),
    themeToggle: $('#theme-toggle'),
    sunIcon: $('#theme-icon-sun'),
    moonIcon: $('#theme-icon-moon'),
    toastContainer: $('#toast-container'),
  };

  /* ---------- Theme ---------- */
  function initTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const dark = saved ? saved === 'dark' : prefersDark;
    setTheme(dark, false);
  }

  function setTheme(dark, persist = true) {
    document.documentElement.classList.toggle('dark', dark);
    el.sunIcon.classList.toggle('hidden', dark);
    el.moonIcon.classList.toggle('hidden', !dark);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', dark ? '#111119' : '#3C3C6E');
    if (persist) localStorage.setItem(THEME_KEY, dark ? 'dark' : 'light');
  }

  el.themeToggle.addEventListener('click', () => {
    const isDark = document.documentElement.classList.contains('dark');
    setTheme(!isDark);
  });

  /* ---------- Derived data ---------- */
  function getCategories() {
    const set = new Set();
    tasks.forEach((t) => { if (t.category) set.add(t.category); });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }

  function getFilteredTasks() {
    const term = searchTerm.trim().toLowerCase();
    return tasks
      .filter((t) => {
        if (filter === 'active' && t.completed) return false;
        if (filter === 'completed' && !t.completed) return false;
        if (categoryFilter !== 'all' && t.category !== categoryFilter) return false;
        if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
        if (term) {
          const hay = (t.title + ' ' + (t.notes || '') + ' ' + (t.category || '')).toLowerCase();
          if (!hay.includes(term)) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        const order = { high: 0, medium: 1, low: 2 };
        if (order[a.priority] !== order[b.priority]) return order[a.priority] - order[b.priority];
        return b.createdAt - a.createdAt;
      });
  }

  /* ---------- Rendering ---------- */
  function formatDueDate(dateStr) {
    if (!dateStr) return null;
    const due = new Date(dateStr + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diffDays = Math.round((due - today) / 86400000);
    let label;
    if (diffDays === 0) label = 'Today';
    else if (diffDays === 1) label = 'Tomorrow';
    else if (diffDays === -1) label = 'Yesterday';
    else if (diffDays > 1 && diffDays < 7) label = due.toLocaleDateString(undefined, { weekday: 'short' });
    else label = due.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    return { label, overdue: diffDays < 0 };
  }

  function priorityLabel(p) {
    return p === 'high' ? 'High' : p === 'medium' ? 'Medium' : 'Low';
  }

  function checkIconSvg() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>';
  }

  function editIconSvg() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>';
  }

  function trashIconSvg() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>';
  }

  function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  function renderCategoryOptions() {
    const cats = getCategories();
    const current = el.categoryFilter.value;
    el.categoryFilter.innerHTML = '<option value="all">All categories</option>' +
      cats.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    if (cats.includes(current)) el.categoryFilter.value = current;
    else categoryFilter = 'all';

    el.categorySuggestions.innerHTML = cats.map((c) => `<option value="${escapeHtml(c)}"></option>`).join('');
  }

  function renderStats() {
    const total = tasks.length;
    const done = tasks.filter((t) => t.completed).length;
    const active = total - done;
    const pct = total === 0 ? 0 : Math.round((done / total) * 100);
    el.statTotal.textContent = total;
    el.statActive.textContent = active;
    el.statDone.textContent = done;
    el.statPercent.textContent = pct + '%';
    el.progressFill.style.width = pct + '%';
    el.deleteCompletedBtn.classList.toggle('hidden', done === 0);
  }

  function renderTaskCard(t) {
    const li = document.createElement('li');
    li.className = 'task-card' + (t.completed ? ' completed' : '');
    li.dataset.id = t.id;

    const due = formatDueDate(t.dueDate);
    const chips = [];
    chips.push(`<span class="chip chip-${t.priority}">${priorityLabel(t.priority)}</span>`);
    if (t.category) chips.push(`<span class="chip chip-category">${escapeHtml(t.category)}</span>`);
    if (due) {
      chips.push(`<span class="chip ${due.overdue && !t.completed ? 'chip-overdue' : 'chip-due'}">${due.overdue && !t.completed ? '⚠ ' : ''}${due.label}</span>`);
    }

    li.innerHTML = `
      <button class="task-check" aria-label="${t.completed ? 'Mark as active' : 'Mark as completed'}">${checkIconSvg()}</button>
      <div class="task-body">
        <div class="task-title-row">
          <span class="task-title"></span>
        </div>
        ${t.notes ? `<div class="task-notes"></div>` : ''}
        <div class="task-meta">${chips.join('')}</div>
      </div>
      <div class="task-actions">
        <button class="edit-btn" aria-label="Edit task">${editIconSvg()}</button>
        <button class="del-btn" aria-label="Delete task">${trashIconSvg()}</button>
      </div>
    `;
    li.querySelector('.task-title').textContent = t.title;
    if (t.notes) li.querySelector('.task-notes').textContent = t.notes;

    li.querySelector('.task-check').addEventListener('click', () => toggleComplete(t.id));
    li.querySelector('.edit-btn').addEventListener('click', () => openEditModal(t.id));
    li.querySelector('.del-btn').addEventListener('click', () => requestDelete(t.id));
    return li;
  }

  function render() {
    renderCategoryOptions();
    renderStats();

    const filtered = getFilteredTasks();
    el.taskList.innerHTML = '';

    if (filtered.length === 0) {
      el.taskList.classList.add('hidden');
      el.emptyState.classList.remove('hidden');
      setEmptyStateMessage();
    } else {
      el.emptyState.classList.add('hidden');
      el.taskList.classList.remove('hidden');
      const frag = document.createDocumentFragment();
      filtered.forEach((t) => frag.appendChild(renderTaskCard(t)));
      el.taskList.appendChild(frag);
    }
  }

  function setEmptyStateMessage() {
    if (searchTerm.trim()) {
      el.emptyTitle.textContent = 'No matching tasks';
      el.emptySub.textContent = `Nothing found for "${searchTerm.trim()}".`;
    } else if (filter === 'completed') {
      el.emptyTitle.textContent = 'Nothing completed yet';
      el.emptySub.textContent = 'Finished tasks will show up here.';
    } else if (filter === 'active') {
      el.emptyTitle.textContent = 'You\'re all caught up';
      el.emptySub.textContent = 'No active tasks — nice work!';
    } else if (tasks.length === 0) {
      el.emptyTitle.textContent = 'No tasks yet';
      el.emptySub.textContent = 'Tap the + button to add your first task.';
    } else {
      el.emptyTitle.textContent = 'No matching tasks';
      el.emptySub.textContent = 'Try a different filter.';
    }
  }

  /* ---------- CRUD ---------- */
  function toggleComplete(id) {
    const t = tasks.find((x) => x.id === id);
    if (!t) return;
    t.completed = !t.completed;
    saveTasks();
    render();
    showToast(t.completed ? 'Task completed' : 'Marked as active', 'success');
  }

  function requestDelete(id) {
    pendingDeleteId = id;
    el.confirmTitle.textContent = 'Delete task?';
    el.confirmMessage.textContent = 'This can\'t be undone.';
    openConfirmModal();
  }

  function requestDeleteCompleted() {
    const count = tasks.filter((t) => t.completed).length;
    if (count === 0) return;
    pendingDeleteId = 'COMPLETED';
    el.confirmTitle.textContent = `Delete ${count} completed task${count > 1 ? 's' : ''}?`;
    el.confirmMessage.textContent = 'This can\'t be undone.';
    openConfirmModal();
  }

  function performPendingDelete() {
    if (pendingDeleteId === 'COMPLETED') {
      const before = tasks.length;
      tasks = tasks.filter((t) => !t.completed);
      saveTasks();
      render();
      showToast('Completed tasks deleted', 'success');
    } else if (pendingDeleteId) {
      const idx = tasks.findIndex((t) => t.id === pendingDeleteId);
      if (idx !== -1) {
        tasks.splice(idx, 1);
        saveTasks();
        render();
        showToast('Task deleted', 'success');
      }
    }
    pendingDeleteId = null;
    closeConfirmModal();
  }

  function upsertTaskFromForm(e) {
    e.preventDefault();
    const title = el.taskTitleInput.value.trim();
    if (!title) {
      showToast('Please enter a task title.', 'error');
      el.taskTitleInput.focus();
      return;
    }
    const data = {
      title,
      notes: el.taskNotesInput.value.trim(),
      priority: el.taskPriorityInput.value,
      dueDate: el.taskDueInput.value || '',
      category: el.taskCategoryInput.value.trim(),
    };

    if (editingId) {
      const t = tasks.find((x) => x.id === editingId);
      if (t) Object.assign(t, data);
      showToast('Task updated', 'success');
    } else {
      tasks.unshift({ id: genId(), createdAt: Date.now(), completed: false, ...data });
      showToast('Task added', 'success');
    }
    saveTasks();
    render();
    closeTaskModal();
  }

  /* ---------- Modals ---------- */
  function openAddModal() {
    editingId = null;
    el.modalTitle.textContent = 'New task';
    el.taskForm.reset();
    el.taskPriorityInput.value = 'medium';
    el.taskModal.classList.remove('hidden');
    setTimeout(() => el.taskTitleInput.focus(), 50);
  }

  function openEditModal(id) {
    const t = tasks.find((x) => x.id === id);
    if (!t) return;
    editingId = id;
    el.modalTitle.textContent = 'Edit task';
    el.taskTitleInput.value = t.title;
    el.taskNotesInput.value = t.notes || '';
    el.taskPriorityInput.value = t.priority;
    el.taskDueInput.value = t.dueDate || '';
    el.taskCategoryInput.value = t.category || '';
    el.taskModal.classList.remove('hidden');
    setTimeout(() => el.taskTitleInput.focus(), 50);
  }

  function closeTaskModal() {
    el.taskModal.classList.add('hidden');
    editingId = null;
  }

  function openConfirmModal() {
    el.confirmModal.classList.remove('hidden');
  }
  function closeConfirmModal() {
    el.confirmModal.classList.add('hidden');
    pendingDeleteId = null;
  }

  /* ---------- Toasts ---------- */
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<span class="toast-dot"></span><span></span>`;
    toast.querySelector('span:last-child').textContent = message;
    el.toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('hide');
      setTimeout(() => toast.remove(), 220);
    }, 2200);
  }

  /* ---------- Event wiring ---------- */
  el.fabAdd.addEventListener('click', openAddModal);
  el.modalClose.addEventListener('click', closeTaskModal);
  el.modalCancel.addEventListener('click', closeTaskModal);
  el.taskModal.addEventListener('click', (e) => { if (e.target === el.taskModal) closeTaskModal(); });
  el.taskForm.addEventListener('submit', upsertTaskFromForm);

  el.confirmCancel.addEventListener('click', closeConfirmModal);
  el.confirmModal.addEventListener('click', (e) => { if (e.target === el.confirmModal) closeConfirmModal(); });
  el.confirmOk.addEventListener('click', performPendingDelete);

  el.deleteCompletedBtn.addEventListener('click', requestDeleteCompleted);

  el.searchInput.addEventListener('input', () => {
    searchTerm = el.searchInput.value;
    el.searchClear.classList.toggle('hidden', !searchTerm);
    render();
  });
  el.searchClear.addEventListener('click', () => {
    searchTerm = '';
    el.searchInput.value = '';
    el.searchClear.classList.add('hidden');
    render();
  });

  el.filterTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      el.filterTabs.forEach((x) => { x.classList.remove('active'); x.setAttribute('aria-selected', 'false'); });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      filter = tab.dataset.filter;
      render();
    });
  });

  el.categoryFilter.addEventListener('change', () => {
    categoryFilter = el.categoryFilter.value;
    render();
  });
  el.priorityFilter.addEventListener('change', () => {
    priorityFilter = el.priorityFilter.value;
    render();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!el.confirmModal.classList.contains('hidden')) closeConfirmModal();
      else if (!el.taskModal.classList.contains('hidden')) closeTaskModal();
    }
  });

  /* ---------- Init ---------- */
  function init() {
    initTheme();
    loadTasks();
    saveTasks();
    render();

    el.boot.classList.remove('hidden');
    el.app.classList.remove('hidden');
    setTimeout(() => { el.boot.style.display = 'none'; }, 1500);

    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('service-worker.js').catch((err) => {
          console.warn('Service worker registration failed:', err);
        });
      });
    }
  }

  init();
})();
